﻿
namespace EduardoForm
{
    internal class CategoriasForm
    {
        public CategoriasForm()
        {
        }

        internal void Show()
        {
            throw new NotImplementedException();
        }
    }
}