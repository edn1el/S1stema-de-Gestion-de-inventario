
-- Uso de la base de datos
USE Eduard;

-- Crear tabla Categorias
CREATE TABLE Categorias(
    IdCategoria INT PRIMARY KEY IDENTITY(1,1),
    Nombre VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(120)
);

-- Crear tabla Proveedores
CREATE TABLE Proveedores(
    IdProveedor INT PRIMARY KEY IDENTITY(1,1),
    NombreEmpresa VARCHAR(100) NOT NULL,
    Contacto VARCHAR(50),
    Direccion VARCHAR(150)
);

-- Crear tabla Productos
CREATE TABLE Productos(
    CodigoProducto INT PRIMARY KEY IDENTITY(1,1),
    NombreProduct VARCHAR(100) NOT NULL,
    IdCategoria INT NOT NULL,
    Precio DECIMAL NOT NULL,
    Cantidad INT DEFAULT 1,
    IdProveedor INT NOT NULL,

    CONSTRAINT RelacionIdProveedor FOREIGN KEY (IdProveedor)
        REFERENCES Proveedores(IdProveedor) ON DELETE CASCADE, 
    CONSTRAINT RelacionIdCategorias FOREIGN KEY (IdCategoria)
        REFERENCES Categorias(IdCategoria) ON DELETE CASCADE
);

-- Insertar datos en la tabla Categorias
INSERT INTO Categorias (Nombre, Descripcion)
VALUES 
('Tecnolog�a', 'Gadgets y dispositivos tecnol�gicos'),
('Hogar', 'Art�culos para el hogar y la decoraci�n'),
('Bebidas', 'Bebidas refrescantes y alcoh�licas'),
('Deportes', 'Equipos y accesorios deportivos'),
('Autom�viles', 'Partes y accesorios para veh�culos');

-- Insertar datos en la tabla Proveedores
INSERT INTO Proveedores (NombreEmpresa, Contacto, Direccion)
VALUES
('TechSolutions', 'Mario Garc�a', 'Calle Innovaci�n 345, Ciudad Z'),
('HomeDecor', 'Laura S�nchez', 'Av. Casa Bonita 678, Ciudad Y'),
('DrinkMaster', 'David Hern�ndez', 'Boulevard Bebidas 987, Ciudad X'),
('SportyLife', 'Elena Fern�ndez', 'Carrera del Deporte 123, Ciudad W'),
('AutoParts Co.', 'Javier Mart�nez', 'Ruta Motor 456, Ciudad V');

-- Insertar datos en la tabla Productos
INSERT INTO Productos (NombreProduct, IdCategoria, Precio, Cantidad, IdProveedor)
VALUES
('Tablet Pro Max', 1, 799.99, 40, 1),
('Cortinas Modernas', 2, 29.99, 150, 2),
('Cerveza Artesanal', 3, 5.99, 250, 3),
('Bicicleta de Monta�a', 4, 499.99, 60, 4),
('Filtro de Aceite', 5, 19.99, 300, 5),
('Smartwatch Avanzado', 1, 299.99, 35, 1),
('Sof� Esquinero', 2, 999.99, 20, 2),
('Refresco de Cola', 3, 1.50, 500, 3),
('Bal�n de F�tbol', 4, 24.99, 120, 4),
('Llantas Todo Terreno', 5, 149.99, 100, 5);

